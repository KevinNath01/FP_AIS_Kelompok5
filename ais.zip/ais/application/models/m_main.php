<?php if(!defined('BASEPATH')) exit('No direct script allowed');

class M_main extends CI_Model{

	function get_user($q) {
		return $this->db->get_where('m_user',$q);
	}

	public function reguser($notelp,$nama){
        $this->db->insert('user',['notelp' => $notelp,'nama' => $nama]);
        return $this->db->affected_rows();
    }

	public function cekdata($notelp){
		$this->db->get_where('user',['notelp' => $notelp]);
		return $this->db->affected_rows();
	}

	public function regdriver($notelpd,$namad){
        $this->db->insert('driver',['notelpd' => $notelpd,'namad' => $namad]);
        return $this->db->affected_rows();
    }

	public function cekdatad($notelpd){
		$this->db->get_where('userd',['notelpd' => $notelpd]);
		return $this->db->affected_rows();
	}
}