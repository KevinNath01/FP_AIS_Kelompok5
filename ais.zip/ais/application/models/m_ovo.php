<?php

class M_ovo extends CI_Model
{

    public function getsaldo($notelp)
    {
        $this->db->select('saldo');
        return $this->db->get('user',['notelp' => $notelp])->result_array();
    }

    public function getsaldod($notelpd)
    {
        $this->db->select('saldod');
        return $this->db->get('driver',['notelpd' => $notelpd])->result_array();
    }

    public function topupd($notelpd, $saldobarud)
    {
        $this->db->update('driver', ['saldod'=>$saldobarud], ['notelpd' => $notelpd]);
        return $this->db->affected_rows();
    }

    public function topup($notelp, $saldobaru)
    {
        $this->db->update('user', ['saldo'=>$saldobaru], ['notelp' => $notelp]);
        return $this->db->affected_rows();
    }

    public function getuser($notelp)
    {
        return $this->db->get('user',['notelp' => $notelp])->result_array();
    }

    public function getdriver($notelpd)
    {
        return $this->db->get('driver',['notelpd' => $notelpd])->result_array();
    }

}