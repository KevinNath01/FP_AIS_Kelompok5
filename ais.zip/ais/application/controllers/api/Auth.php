<?php

defined('BASEPATH') OR exit('No direct script access allowed');
use \Firebase\JWT\JWT;

class Auth extends BD_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->model('M_main');
    }

    public function reguser_post()
    {
            $notelp = $this->post('notelp');
            $nama = $this->post('nama');
        
        if($this->m_main->cekdata($notelp) > 0){
            $this->response([
                'status' => FALSE,
                'data' => 'Nomor sudah terdaftar !'
            ], REST_Controller::HTTP_BAD_REQUEST);  
        }     
        else if($this->M_main->reguser($notelp,$nama) > 0){
            $this->response([
                'status' => TRUE,
                'massage' => 'User telah ditambahkan'
            ], REST_Controller::HTTP_CREATED);  
        } else {
            $this->response([
                'status' => FALSE,
                'data' => 'Gagal membuat data baru'
            ], REST_Controller::HTTP_BAD_REQUEST);  
        }     
        }

        public function regdriver_post()
    {
            $notelpd = $this->post('notelpd');
            $namad = $this->post('namad');
        
        if($this->m_main->cekdatad($notelpd) > 0){
            $this->response([
                'status' => FALSE,
                'data' => 'Nomor sudah terdaftar !'
            ], REST_Controller::HTTP_BAD_REQUEST);  
        }     
        else if($this->M_main->regdriver($notelpd,$namad) > 0){
            $this->response([
                'status' => TRUE,
                'massage' => 'User telah ditambahkan'
            ], REST_Controller::HTTP_CREATED);  
        } else {
            $this->response([
                'status' => FALSE,
                'data' => 'Gagal membuat data baru'
            ], REST_Controller::HTTP_BAD_REQUEST);  
        }     
        }
    

}

