<?php

defined('BASEPATH') OR exit('No direct script access allowed');
use \Firebase\JWT\JWT;

class Ovo extends BD_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->model('m_ovo');
    }

    public function user_get()
    {
        $notelp = $this->get('notelp');
        if($notelp === null){
            $this->response([
                'status' => FALSE,
                'data' => 'Insert Phone Number'
            ], REST_Controller::HTTP_NOT_FOUND); 
        }else{
        $ovo = $this->m_ovo->getuser($notelp);
        }
        
        if($ovo){
            $this->response([
                'status' => TRUE,
                'data' => $ovo
            ], REST_Controller::HTTP_OK); 
        } else {
            $this->response([
                'status' => FALSE,
                'data' => 'not found'
            ], REST_Controller::HTTP_NOT_FOUND);  
        }
    } 

    public function driver_get()
    {
        $notelpd = $this->get('notelpd');
        if($notelpd === null){
            $this->response([
                'status' => FALSE,
                'data' => 'Insert Phone Number'
            ], REST_Controller::HTTP_NOT_FOUND); 
        }else{
        $ovod = $this->m_ovo->getdriver($notelpd);
        }
        
        if($ovod){
            $this->response([
                'status' => TRUE,
                'data' => $ovod
            ], REST_Controller::HTTP_OK); 
        } else {
            $this->response([
                'status' => FALSE,
                'data' => 'not found'
            ], REST_Controller::HTTP_NOT_FOUND);  
        }
    } 

    public function user_put()
    {
        $notelp = $this->put('notelp');
        $topup = $this->put('topup');
        $inttopup = (int)$topup;
        if($notelp === null){
            $this->response([
                'status' => FALSE,
                'data' => 'Insert Phone Number'
            ], REST_Controller::HTTP_NOT_FOUND); 
        }else{
            if($this->m_main->cekdata($notelp) < 0){
                $this->response([
                    'status' => FALSE,
                    'data' => 'Nomor Tidak Terdaftar !'
                ], REST_Controller::HTTP_BAD_REQUEST);  
            } 
        $ovolama = $this->m_ovo->getsaldo($notelp);
        //$json = json_encode($ovolama);
        $ovola = $ovolama[0]['saldo'];
        //echo $ovola;
        $saldobaru = $inttopup + $ovola ; 
        $ovobaru = $this->m_ovo->topup($notelp,$saldobaru);
        }
        if($ovobaru){
            $this->response([
                'status' => TRUE,
                'message' => 'Top up berhasil !!'
            ], REST_Controller::HTTP_OK); 
        } else {
            $this->response([
                'status' => FALSE,
                'data' => 'Gagal update data'
            ], REST_Controller::HTTP_BAD_REQUEST); 
        }
    } 

    public function bayar_put()
    {
        $notelp = $this->put('notelp');
        $notelpd = $this->put('notelpd');
        $harga = $this->put('harga');
        $intharga = (int)$harga;
        if($notelp === null){
            $this->response([
                'status' => FALSE,
                'data' => 'Insert Phone Number'
            ], REST_Controller::HTTP_NOT_FOUND); 
        }else{
            if($this->m_main->cekdata($notelp) < 0){
                $this->response([
                    'status' => FALSE,
                    'data' => 'Nomor Tidak Terdaftar !'
                ], REST_Controller::HTTP_BAD_REQUEST);  
            } 
        $ovolama = $this->m_ovo->getsaldo($notelp);
        //$json = json_encode($ovolama);
        $ovola = $ovolama[0]['saldo'];
        //echo $ovola;
        $ovolamad = $this->m_ovo->getsaldod($notelpd);
        $ovolad = $ovolamad[0]['saldod'];
        $saldobaru = $ovola - $intharga; 
        $saldobarud = $ovolad + $intharga;
        if($saldobaru < 0){
            $this->response([
                'status' => FALSE,
                'data' => 'Saldo tidak cukup !'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
        $ovobaru = $this->m_ovo->topup($notelp,$saldobaru);
        $uangdriver = $this->m_ovo->topupd($notelpd,$saldobarud);
        if($ovobaru){
            $this->response([
                'status' => TRUE,
                'message' => 'Pembayaran Berhasil !!'
            ], REST_Controller::HTTP_OK); 
        } else {
            $this->response([
                'status' => FALSE,
                'data' => 'Gagal update data'
            ], REST_Controller::HTTP_BAD_REQUEST); 
        }
        }
    }} 
    
    public function driverwd_put()
    {

        $notelpd = $this->put('notelpd');
        $total = $this->put('total');
        $inttotal = (int)$total;
        if($notelpd === null){
            $this->response([
                'status' => FALSE,
                'data' => 'Insert Phone Number'
            ], REST_Controller::HTTP_NOT_FOUND); 
        }else{
            if($this->m_main->cekdata($notelpd) < 0){
                $this->response([
                    'status' => FALSE,
                    'data' => 'Nomor Tidak Terdaftar !'
                ], REST_Controller::HTTP_BAD_REQUEST);  
            } 
        $ovolamad = $this->m_ovo->getsaldod($notelpd);
        $ovolad = $ovolamad[0]['saldod'];
        $saldobarud = $ovolad - $inttotal;
        if($saldobarud < 0){
            $this->response([
                'status' => FALSE,
                'data' => 'Saldo tidak cukup !'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
        $uangdriver = $this->m_ovo->topupd($notelpd,$saldobarud);
        if($uangdriver){
            $this->response([
                'status' => TRUE,
                'message' => 'Penarikan Berhasil !!'
            ], REST_Controller::HTTP_OK); 
        } else {
            $this->response([
                'status' => FALSE,
                'data' => 'Gagal update data'
            ], REST_Controller::HTTP_BAD_REQUEST); 
        }
        }
    }}  

}